<?php
class NexmoViewList extends SugarView{
    public function display()
    {
        echo '<h1>Hello World</h1>';
    }
}  